package testRunner;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions

(
		features = ".//Features/Login.feature",
		glue ="stepDefinations",
		dryRun=false,

		plugin = {
				
		        "pretty",
		        "json:target/cucumber/cucumber.json",
		        "html:target/cucumber/cucumber.html"
		        
		        }

)
public class TestRun  extends AbstractTestNGCucumberTests 
{

}