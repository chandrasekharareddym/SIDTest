package stepDefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
//import io.github.bonigarcia.wdm.WebDriverManager;
import pageObjects.LoginPage;

public class Steps {
	
	public WebDriver driver;
	public LoginPage lp;
	
	@Given("User Lanunch Chrome browser")
	public void user_lanunch_chrome_browser()
	{
	    driver = new ChromeDriver();
		lp = new LoginPage(driver);
	}

	@When("User opens URL {string}")
	public void user_opens_url(String url) throws Exception  {
		
		driver.manage().window().maximize();
		Thread.sleep(1000);
		driver.get(url);
		
		Thread.sleep(2000);
		
	}

	@When("^User enters Email as ([^\"]*) and Password as([^\"]*)$")
	public void user_enters_email_as_and_password_as(String email, String pwd) 
	{
		
		lp.setUserName(email);
		lp.setPassword(pwd);
		
	}
	
	@When("Customer enters Email as {string} and Password as {string}")
	public void customer_enters_email_as_and_password_as(String email, String pwd) 
	{
    
	lp.setUserName(email);
	lp.setPassword(pwd);
	
    }


	@When("Clicks on Login")
	public void clicks_on_login() throws Exception 
	{
		lp.clickLogin();
		Thread.sleep(3000);
	}

	@Then("Page Title should be {string}")
	public void page_title_should_be(String title)
	{
		
		if (driver.getPageSource().contains("Login was unsuccessful."))
		{
			System.out.println(driver.getTitle());
			driver.close();
			
			Assert.assertTrue(false);			
		}
		else
		{
			System.out.println(driver.getTitle());
			Assert.assertEquals(title, driver.getTitle());
		}
		
		
	}

	@When("User click on Log Out link")
	public void user_click_on_log_out_link() throws InterruptedException 
	{
		lp.clickLogout();
		Thread.sleep(3000);
	}

	@Then("close browser")
	public void close_browser() 
	{
		driver.quit();
	}
	

}
